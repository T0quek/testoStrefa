<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        //Administrator
        DB::table("users")->insert([
            ["name" => "Tomasz Gudyka", "email" => "tomaszgudyka@gmail.com", "role"=>"admin", "password" => '$2y$10$/W0epjSAQ62nljKzo1W6OuCnxzQqpiZROUDk6j9jR2Ld9FseP5yOC', "status"=>1],
            ["name" => "Szymon Soszka", "email" => "272224@student.pwr.edu.pl", "role"=>"admin", "password" => '$2y$10$56Em0gI/6yAXzeYXRexabuud0Xof5bP.cbLKIbSgPkdqlVmTpG0su', "status"=>1],
            ["name" => "Kamil Kałużny", "email" => "apps@ximix.pl", "role"=>"admin", "password" => '$2y$10$vgEtK/v7vdTHXhlW9sBoVul3srGoE42vltJwclvmpwVB6mcIyv0Zu', "status"=>1],
       ]);

        //
        DB::table("courses")->insert([
            ["name"=>"Kryptografia", "description"=>"Kurs obejmuje zakres wiedzy z przedmiotu Kryptografia 1, zawiera sekcje tematyczne: kryptografia symetryczna, kryptografia asymetryczna, systemy kryptograficzne oraz certyfikaty"],
            ["name"=>"Usługi i aplikacje multimedialne", "description"=>"Kurs obejmuje zakres wiedzy z przedmiotu Usługi i aplikacje ..."]
        ]);

        DB::table("sets")->insert([
            ["name"=>"Kryptografia symetryczna", "description"=>"Opis zestawu", "course_id"=>1, "creator_id"=>1],
            ["name"=>"Kryptografia asymetryczna", "description"=>"Opis zestawu", "course_id"=>1, "creator_id"=>1],
            ["name"=>"Systemy kryptograficzne", "description"=>"Opis zestawu", "course_id"=>1, "creator_id"=>1],
            ["name"=>"Certyfikaty", "description"=>"Opis zestawu", "course_id"=>1, "creator_id"=>1],
            ["name"=>"Multimedia", "description"=>"Opis zestawu multimedia", "course_id"=>2, "creator_id"=>2],
            ["name"=>"Netflix", "description"=>"Opis zestawu Netflix", "course_id"=>2, "creator_id"=>1],
            ["name"=>"Usługi sieciowe", "description"=>"Opis zestawu Usługi sieciowe", "course_id"=>2, "creator_id"=>2],
        ]);

        DB::table("accesses")->insert([
           ["user_id"=>1, "creator_id"=>1, "set_id"=>1],
           ["user_id"=>1, "creator_id"=>1, "set_id"=>2],
           ["user_id"=>1, "creator_id"=>1, "set_id"=>3],
           ["user_id"=>1, "creator_id"=>1, "set_id"=>4],
           ["user_id"=>1, "creator_id"=>1, "set_id"=>5],
           ["user_id"=>1, "creator_id"=>1, "set_id"=>6],
        ]);

        DB::table("questions")->insert([
            ["type"=>1, "set_id"=>1, "creator_id"=>1, "data"=>"{\"title\": \"Która z poniższych metod jest uznawana za symetryczną metodę szyfrowania?\", \"type\": 1, \"answers\": [\"RSA\", \"AES\", \"DSA\", \"Diffie-Hellman\"], \"correctAnswers\": [2]}"],
            ["type"=>2, "set_id"=>1, "creator_id"=>1, "data"=>"{\"title\": \"Które z poniższych algorytmów są używane w kryptografii asymetrycznej?\", \"type\": 2, \"answers\": [\"RSA\", \"ECDSA\", \"AES\", \"Blowfish\"], \"correctAnswers\": [1, 2]}"],
            ["type"=>3, "set_id"=>1, "creator_id"=>1, "data"=>"{\"title\": \"Wybierz odpowiednie terminy do wypełnienia luk: Szyfrowanie symetryczne używa [0] klucza, podczas gdy szyfrowanie asymetryczne używa [1] kluczy.\", \"type\": 3, \"answers\": [[\"jednego\", \"dwóch\", \"wielu\"], [\"jednego\", \"dwóch\", \"wielu\"]], \"correctAnswers\": [1, 2]}"],
            ["type"=>4, "set_id"=>1, "creator_id"=>1, "data"=>"{\"title\": \"Podaj standardową długość klucza w AES-128\", \"type\": 4, \"suffix\": \"bit\", \"correctAnswers\": [\"128\"]}"],
            ["type"=>1, "set_id"=>1, "creator_id"=>1, "data"=>"{\"title\": \"Który z poniższych algorytmów nie jest algorytmem szyfrowania symetrycznego?\", \"type\": 1, \"answers\": [\"Blowfish\", \"RC4\", \"RSA\", \"DES\"], \"correctAnswers\": [3]}"],
            ["type"=>2, "set_id"=>1, "creator_id"=>1, "data"=>"{\"title\": \"Które z poniższych funkcji są funkcjami skrótu?\", \"type\": 2, \"answers\": [\"MD5\", \"SHA-256\", \"RSA\", \"AES\"], \"correctAnswers\": [1, 2]}"],
            ["type"=>3, "set_id"=>1, "creator_id"=>1, "data"=>"{\"title\": \"Skrót MD5 ma [0] bitów, a SHA-256 ma [1] bitów.\", \"type\": 3, \"answers\": [[\"128\", \"160\", \"256\"], [\"128\", \"160\", \"256\"]], \"correctAnswers\": [1, 3]}"],
            ["type"=>4, "set_id"=>1, "creator_id"=>1, "data"=>"{\"title\": \"Podaj standardową długość klucza w SHA-1\", \"type\": 4, \"suffix\": \"bit\", \"correctAnswers\": [\"160\"]}"],
            ["type"=>1, "set_id"=>1, "creator_id"=>1, "data"=>"{\"title\": \"Który algorytm używa pary kluczy publicznego i prywatnego?\", \"type\": 1, \"answers\": [\"AES\", \"RSA\", \"DES\", \"Blowfish\"], \"correctAnswers\": [2]}"],
            ["type"=>2, "set_id"=>1, "creator_id"=>1, "data"=>"{\"title\": \"Które z poniższych są algorytmami szyfrowania symetrycznego?\", \"type\": 2, \"answers\": [\"DES\", \"3DES\", \"AES\", \"ECDSA\"], \"correctAnswers\": [1, 2, 3]}"],
            // Dodaj dalsze pytania w podobnym formacie
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
    }
};
